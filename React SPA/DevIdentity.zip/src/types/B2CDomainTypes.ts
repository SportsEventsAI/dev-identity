// src/services/auth/types/enums/B2CDomainTypes.ts
export enum B2CDomainTypes {
    Tenant = 'tenant',
    Login = 'login'
}