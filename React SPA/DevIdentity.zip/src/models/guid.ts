export type guid = string;
