export const minLength = (value: string, length: number): boolean => value.length >= length;
