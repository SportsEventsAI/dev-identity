// src/components/Auth/Login.tsx
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { LoginAction } from '../../redux/slices/authSlice';
import LoginService from '../../services/Auth/LoginService';

/**
 * Represents the Login component.
 * @filename src/components/Auth/Login.tsx
 */
const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);
    const dispatch = useDispatch();

    /**
     * Handles the login form submission.
     * @param e - The form event.
     */
    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        try {
            const authResponse = await LoginService(username, password);
            dispatch(LoginAction({ user: authResponse.user, token: authResponse.token }));
        } catch (error: any) {
            setError(error.message);
        }
    };

    return (
        <form onSubmit={handleLogin}>
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" />
            <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
            />
            <button type="submit">Login</button>
            {error && <p>{error}</p>}
        </form>
    );
};

export default Login;
